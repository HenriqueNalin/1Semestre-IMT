for i in range(5):
    print(i)

for numero in range(10):
    if numero % 2 == 0: 
        print("O número", numero, "é par")

for coluna1 in range(1, 11):
    print("Tabuada do", coluna1)
    for coluna2 in range(11) : 
        print(coluna1, "x", coluna2, " = ", coluna1 * coluna2)