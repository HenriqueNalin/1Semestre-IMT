n1 = int(input("Primeiro número: "))
n2 = int(input("Segundo número: "))

if n2%3 == 0:
    print("A soma é:", n1 + n2)
else:
    print("----------------")

