codigo = float(input("Insira o seu código: "))
if codigo == 310:
    salario = float(input("Insira o valor do seu salário: "))
    result1 = salario + (salario * 5/100)
    dif1 = result1 - salario
    print("O seu novo salário é de:", result1 )
    print("A diferença entre o seu novo salário e o salário antigo é de:", dif1)
if codigo == 456:
    salario = float(input("Insira o valor do seu salário: "))
    result2 = salario + (salario * 7.5/100)
    dif2 = result2 - salario
    print("O seu novo salário é de:", result2 )
    print("A diferença entre o seu novo salário e o salário antigo é de:", dif2)
if codigo == 885:
    salario = float(input("Insira o valor do seu salário: "))
    result3 = salario + (salario*10/100)
    dif3 = result3 - salario
    print("O seu novo salário é de:", result3 )
    print("A diferença entre o seu novo salário e o salário antigo é de:", dif3 )
else:
    salario = float(input("Insira o valor do seu salário:"))
    result4 = salario + (salario * 15/100)
    dif4 = result4 - salario
    print("O seu novo salário é de:", result4)
    print("A diferença entre o seu novo salário e o salário antigo é de:", dif4 )







        

