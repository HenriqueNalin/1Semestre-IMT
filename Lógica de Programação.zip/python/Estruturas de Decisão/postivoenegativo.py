n = int(input("Número: "))
if n >= 0:
    print("O número é positivo")
else:
    print("O número é negativo")