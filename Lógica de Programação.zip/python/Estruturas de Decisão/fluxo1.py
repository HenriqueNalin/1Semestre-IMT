n1 = int(input("Número 1:"))
n2 = int(input("Número 2:"))

if n1 > n2:
    print("O maior é", n1 )
else:
    print("O maior é", n2 )