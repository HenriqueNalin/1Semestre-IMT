 
n = int(input("Número: "))
if n%2 == 0:
    print("O número é par")
else:
    print("O número é impar")