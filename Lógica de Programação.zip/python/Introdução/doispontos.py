xa = float(input("\nxA = "))
ya = float(input("\nyA = "))
xb = float(input("\nxB = "))
yb = float(input("\nyB = "))

distancia = ((xb-xa)**2 + (yb-ya)**2)**0.5
print("\nA distância vale", distancia)
