import math
print("PI = ", math.pi)
print("seno 90 = ", math.sin(math.pi/2))
print("seno 90 = ", math.sin(math.radians(90)))
print("arcosseno de 1 (em graus) = ", math.degrees(math.asin(1)))

print("raiz quadradada de 2 =", math.sqrt(2))
print("raiz quadradada de 2 =", 2**(1/2))



      