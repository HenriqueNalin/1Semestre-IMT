import distancia 

print(distancia.euclidiana(1, 1, 4, 5))

print(distancia.haversine(-23.647955, -23.585578, -46.5768199, -46.6122539))