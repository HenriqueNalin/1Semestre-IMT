clearscreen()
t = Turtle()
t.speed(13)

t.left(45)
for i in range(4):
    t.forward(100)
    t.left(90)
t.forward(100)
for x in range(4):
    t.forward(100)
    t.right(90)