N = -1
while N<0:
    N = int(input("Entre com um número positivo: "))
    
print("Obrigado!")