quadrados=[]
for n in range(10):
    quadrados.append(n**2)
    print(quadrados)
