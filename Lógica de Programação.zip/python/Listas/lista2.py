pares = []
for x in [1, 2, 3]: 
    for y in [4, 5, 6]:
        pares.append((x, y))
        print(pares)